from tkinter import *
from tkinter import ttk, filedialog, messagebox
# Importamos el motor de lógica
import airport as ap 

# ── Datos en memoria ──────────────────────────────────────────────────────────
airports_list = []

# ── Funciones de Interfaz (Llaman a airport.py) ────────────────────────────────

def RefrescarVista():
    """Única función que toca la UI para mostrar los datos actuales."""
    # Habilitamos la caja de texto para limpiar y escribir
    listaText.config(state=NORMAL)
    listaText.delete('1.0', END)
    
    n_s, n = 0, len(airports_list)
    
    if n == 0:
        listaText.insert(END, "(La lista está vacía)")
    else:
        for a in airports_list:
            # Comprobamos si es Schengen (usando la lógica de airport.py)
            ap.SetSchengen(a) 
            if a.schengen: n_s += 1
            
            marca = "[S]" if a.schengen else "[NS]"
            linea = f"{marca} {a.ICAO.ljust(6)} | Lat: {round(a.latitude, 4):.4f} | Lon: {round(a.longitude, 4):.4f}\n"
            listaText.insert(END, linea)
            
    # Actualizamos contadores
    contadorLabel.config(text=f"Total: {n}  |  Schengen: {n_s}")
    # Bloqueamos la caja para que sea de solo lectura
    listaText.config(state=DISABLED)

def ClickCargar():
    global airports_list
    ruta = filedialog.askopenfilename(title="Abrir base de datos", filetypes=[("Texto", "*.txt")])
    if ruta:
        # La lógica de carga está en airport.py
        nuevos = ap.LoadAirports(ruta)
        if nuevos:
            for n in nuevos:
                ap.AddAirport(airports_list, n)
            RefrescarVista()
            statusLabel.config(text=f"Archivo cargado: {ruta}")
        else:
            messagebox.showerror("Error", "El archivo no es válido o está vacío.")

def ClickGuardar():
    if not airports_list:
        messagebox.showwarning("Aviso", "No hay datos para guardar.")
        return
    ruta = filedialog.asksaveasfilename(defaultextension=".txt", filetypes=[("Texto", "*.txt")])
    if ruta:
        # La lógica de guardado está en airport.py
        res = ap.SaveSchengenAirports(airports_list, ruta)
        if res == 0:
            messagebox.showinfo("Éxito", "Aeropuertos Schengen guardados correctamente.")
        else:
            messagebox.showerror("Error", "No se pudo guardar el archivo.")

def ClickAnadir():
    icao = icaoEntry.get().strip().upper()
    lat_s = latEntry.get().strip()
    lon_s = lonEntry.get().strip()
    
    if not icao:
        messagebox.showwarning("Dato incompleto", "Introduce al menos el código ICAO.")
        return

    try:
        # Intentamos crear el objeto con los datos de las cajas
        lat = float(lat_s) if lat_s else 0.0
        lon = float(lon_s) if lon_s else 0.0
        nuevo = ap.Airport(icao, lat, lon)
        ap.SetSchengen(nuevo)
        
        # --- CORRECCIÓN CLAVE ---
        # Ejecutamos la acción en airport.py y comprobamos si devuelve 0 (Éxito)
        resultado = ap.AddAirport(airports_list, nuevo)
        
        if resultado == 0:
            RefrescarVista()
            statusLabel.config(text=f"Añadido: {icao}")
            # Limpiar entradas
            icaoEntry.delete(0, END); latEntry.delete(0, END); lonEntry.delete(0, END)
        else:
            messagebox.showwarning("Duplicado", f"El aeropuerto {icao} ya existe en la lista.")
            
    except ValueError:
        messagebox.showerror("Error de formato", "Latitud y Longitud deben ser números decimales.")

def ClickEliminar():
    icao = icaoEntry.get().strip().upper()
    if not icao:
        messagebox.showwarning("Aviso", "Escribe el ICAO en la caja para eliminarlo.")
        return
    
    # La acción se ejecuta en airport.py
    res = ap.RemoveAirport(airports_list, icao)
    if res == 0:
        RefrescarVista()
        statusLabel.config(text=f"Eliminado: {icao}")
    else:
        messagebox.showerror("Error", f"No se encontró el aeropuerto {icao}.")

# ── Configuración de la Ventana Principal ─────────────────────────────────────
window = Tk()
window.title("Airport Manager Pro")
window.geometry("650x600")

# Grid configuration
for i in range(10): window.rowconfigure(i, weight=1)
for i in range(4): window.columnconfigure(i, weight=1)

# Título
Label(window, text="SISTEMA DE GESTIÓN AEROPORTUARIA", font=("Arial", 14, "bold")).grid(row=0, column=0, columnspan=4, pady=10)

# Fila 1: Operaciones de Archivo
Label(window, text="Operaciones de Archivo:").grid(row=1, column=0, sticky="e", padx=5)
ttk.Button(window, text="Cargar Aeropuertos", command=ClickCargar).grid(row=1, column=1, columnspan=2, sticky="ew", padx=5)
ttk.Button(window, text="Guardar Schengen", command=ClickGuardar).grid(row=1, column=3, sticky="ew", padx=5)

# Fila 2: Gestión de Aeropuertos
Label(window, text="ICAO:").grid(row=2, column=0, sticky="e")
icaoEntry = ttk.Entry(window)
icaoEntry.grid(row=2, column=1, sticky="ew", padx=5)
ttk.Button(window, text="Añadir", command=ClickAnadir).grid(row=2, column=2, sticky="ew", padx=5)
ttk.Button(window, text="Eliminar", command=ClickEliminar).grid(row=2, column=3, sticky="ew", padx=5)

# Fila 3: Coordenadas
Label(window, text="Lat:").grid(row=3, column=0, sticky="e")
latEntry = ttk.Entry(window)
latEntry.grid(row=3, column=1, sticky="ew", padx=5)
Label(window, text="Lon:").grid(row=3, column=2, sticky="e")
lonEntry = ttk.Entry(window)
lonEntry.grid(row=3, column=3, sticky="ew", padx=5)

# Fila 4: Visualización
ttk.Button(window, text="Ver Gráfico Estadístico", command=lambda: ap.PlotAirports(airports_list)).grid(row=4, column=0, columnspan=2, sticky="ew", padx=5, pady=10)
ttk.Button(window, text="Exportar a Google Earth (KML)", command=lambda: ap.MapAirports(airports_list, "mapa.kml")).grid(row=4, column=2, columnspan=2, sticky="ew", padx=5, pady=10)

# Fila 5: Otros
ttk.Button(window, text="Limpiar Lista Completa", command=lambda: [airports_list.clear(), RefrescarVista()]).grid(row=5, column=0, columnspan=4, sticky="ew", padx=10)

# Fila 6: Contadores y Estado
contadorLabel = Label(window, text="Total: 0  |  Schengen: 0", font=("Arial", 10, "italic"))
contadorLabel.grid(row=6, column=0, columnspan=4)
statusLabel = Label(window, text="Listo.", relief="sunken", anchor="w")
statusLabel.grid(row=7, column=0, columnspan=4, sticky="ew", padx=10)

# Fila 8: Lista con Scrollbar (Solución al desbordamiento)
frameLista = Frame(window)
frameLista.grid(row=8, column=0, columnspan=4, sticky="nsew", padx=10, pady=10)

scroll = Scrollbar(frameLista)
scroll.pack(side=RIGHT, fill=Y)

listaText = Text(frameLista, font=("Courier New", 10), height=12, yscrollcommand=scroll.set)
listaText.pack(side=LEFT, fill=BOTH, expand=True)
scroll.config(command=listaText.yview)

# Inicialización
RefrescarVista()
window.mainloop()