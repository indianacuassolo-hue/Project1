"""
interface.py
Graphical interface for the Airport Management Tool (Version 1).
This file contains ONLY UI code (widgets, dialogs, display).
All logic (validation, data manipulation, file I/O, plots) lives in airport.py.
"""

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from airport import (
    LoadAirports, SaveSchengenAirports,
    AddAirport, RemoveAirport,
    SetAllSchengen, CountSchengen,
    CreateAirport, PlotAirports, MapAirports
)

# ── Colour palette ────────────────────────────────────────────────────────────
BG       = "#0d1117"
PANEL    = "#161b22"
BORDER   = "#30363d"
ACCENT   = "#58a6ff"
ACCENT2  = "#3fb950"
WARN     = "#f85149"
TEXT     = "#e6edf3"
MUTED    = "#8b949e"
ENTRY_BG = "#21262d"


# ── Reusable widget helpers ───────────────────────────────────────────────────
def styled_btn(parent, text, command, color=ACCENT, width=18):
    btn = tk.Button(
        parent, text=text, command=command,
        bg=color, fg=BG, activebackground=color, activeforeground=BG,
        font=("Courier New", 10, "bold"), relief="flat",
        cursor="hand2", width=width, pady=6
    )
    btn.bind("<Enter>", lambda e: btn.config(bg=TEXT))
    btn.bind("<Leave>", lambda e: btn.config(bg=color))
    return btn


def styled_entry(parent, textvariable=None, width=20):
    return tk.Entry(
        parent, textvariable=textvariable, width=width,
        bg=ENTRY_BG, fg=TEXT, insertbackground=ACCENT,
        relief="flat", font=("Courier New", 11),
        highlightthickness=1, highlightcolor=ACCENT,
        highlightbackground=BORDER
    )


def make_label(parent, text, fg=MUTED, font_size=9, **kwargs):
    return tk.Label(parent, text=text, bg=PANEL, fg=fg,
                    font=("Courier New", font_size), **kwargs)


# ══════════════════════════════════════════════════════════════════════════════
class AirportApp:
    def __init__(self, root):
        self.root = root
        self.root.title("✈  Airport Manager — Version 1")
        self.root.configure(bg=BG)
        self.root.geometry("1100x700")
        self.root.minsize(900, 600)

        self.airports = []  # shared data list — passed to airport.py functions

        self._build_header()
        self._build_main()
        self._build_statusbar()

    # ── Header ────────────────────────────────────────────────────────────────
    def _build_header(self):
        hdr = tk.Frame(self.root, bg=PANEL, height=56)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        tk.Label(hdr, text="✈  AIRPORT MANAGER", bg=PANEL, fg=ACCENT,
                 font=("Courier New", 16, "bold")).pack(side="left", padx=24, pady=12)
        self.count_lbl = tk.Label(hdr, text="0 airports loaded",
                                  bg=PANEL, fg=MUTED, font=("Courier New", 10))
        self.count_lbl.pack(side="right", padx=24)

    # ── Main layout ───────────────────────────────────────────────────────────
    def _build_main(self):
        main = tk.Frame(self.root, bg=BG)
        main.pack(fill="both", expand=True)
        self._build_sidebar(main)
        self._build_content(main)

    # ── Sidebar ───────────────────────────────────────────────────────────────
    def _build_sidebar(self, parent):
        sb = tk.Frame(parent, bg=PANEL, width=220)
        sb.pack(side="left", fill="y")
        sb.pack_propagate(False)

        def section(title):
            tk.Label(sb, text=title, bg=PANEL, fg=MUTED,
                     font=("Courier New", 8)).pack(anchor="w", padx=16, pady=(10, 2))

        def sep():
            tk.Frame(sb, bg=BORDER, height=1).pack(fill="x", padx=12, pady=4)

        tk.Label(sb, text="OPERATIONS", bg=PANEL, fg=MUTED,
                 font=("Courier New", 8, "bold")).pack(anchor="w", padx=16, pady=(18, 6))

        section("─── FILE")
        styled_btn(sb, "📂  Load Airports",  self._on_load,         ACCENT,  16).pack(padx=12, pady=3, fill="x")
        styled_btn(sb, "💾  Save Schengen",  self._on_save_schengen,ACCENT,  16).pack(padx=12, pady=3, fill="x")
        sep()

        section("─── AIRPORT")
        styled_btn(sb, "➕  Add Airport",    self._on_add,          ACCENT2, 16).pack(padx=12, pady=3, fill="x")
        styled_btn(sb, "➖  Remove Airport", self._on_remove,       WARN,    16).pack(padx=12, pady=3, fill="x")
        styled_btn(sb, "🌍  Set Schengen",   self._on_set_schengen, ACCENT,  16).pack(padx=12, pady=3, fill="x")
        sep()

        section("─── VISUALISE")
        styled_btn(sb, "📊  Plot Chart",     self._on_plot,         ACCENT,  16).pack(padx=12, pady=3, fill="x")
        styled_btn(sb, "🗺   Export KML",     self._on_export_kml,   ACCENT,  16).pack(padx=12, pady=3, fill="x")
        sep()

        styled_btn(sb, "🗑   Clear All",      self._on_clear,        WARN,    16).pack(padx=12, pady=3, fill="x")

    # ── Content area (table + detail) ─────────────────────────────────────────
    def _build_content(self, parent):
        content = tk.Frame(parent, bg=BG)
        content.pack(side="left", fill="both", expand=True, padx=16, pady=16)

        # Title + search row
        title_row = tk.Frame(content, bg=BG)
        title_row.pack(fill="x", pady=(0, 8))
        tk.Label(title_row, text="AIRPORT LIST", bg=BG, fg=TEXT,
                 font=("Courier New", 12, "bold")).pack(side="left")

        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *_: self._refresh_table())
        sf = tk.Frame(title_row, bg=BG)
        sf.pack(side="right")
        tk.Label(sf, text="🔍 ", bg=BG, fg=MUTED, font=("Courier New", 11)).pack(side="left")
        styled_entry(sf, textvariable=self.search_var, width=16).pack(side="left")

        # Treeview
        cols = ("ICAO", "Latitude", "Longitude", "Schengen")
        style = ttk.Style()
        style.theme_use("default")
        style.configure("Airport.Treeview",
                        background=PANEL, foreground=TEXT,
                        fieldbackground=PANEL, rowheight=28,
                        font=("Courier New", 10))
        style.configure("Airport.Treeview.Heading",
                        background=BORDER, foreground=ACCENT,
                        font=("Courier New", 10, "bold"), relief="flat")
        style.map("Airport.Treeview",
                  background=[("selected", ACCENT)],
                  foreground=[("selected", BG)])

        tf = tk.Frame(content, bg=BG)
        tf.pack(fill="both", expand=True)

        self.tree = ttk.Treeview(tf, columns=cols, show="headings",
                                 style="Airport.Treeview", selectmode="browse")
        for c, w in zip(cols, [90, 150, 150, 110]):
            self.tree.heading(c, text=c, command=lambda col=c: self._sort_by(col))
            self.tree.column(c, width=w, anchor="center")

        vsb = ttk.Scrollbar(tf, orient="vertical",   command=self.tree.yview)
        hsb = ttk.Scrollbar(tf, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        tf.rowconfigure(0, weight=1)
        tf.columnconfigure(0, weight=1)

        self.tree.tag_configure("schengen",    background="#0d2818", foreground=ACCENT2)
        self.tree.tag_configure("no_schengen", background=PANEL,     foreground=TEXT)
        self.tree.bind("<<TreeviewSelect>>", self._on_select)

        # Detail bar
        detail_panel = tk.Frame(content, bg=PANEL, highlightthickness=1,
                                highlightbackground=BORDER)
        detail_panel.pack(fill="x", pady=(10, 0))
        self.detail_lbl = tk.Label(detail_panel,
                                   text="Select an airport to see its details",
                                   bg=PANEL, fg=MUTED,
                                   font=("Courier New", 10), anchor="w", padx=12, pady=8)
        self.detail_lbl.pack(fill="x")

    # ── Status bar ────────────────────────────────────────────────────────────
    def _build_statusbar(self):
        bar = tk.Frame(self.root, bg=BORDER, height=28)
        bar.pack(fill="x", side="bottom")
        bar.pack_propagate(False)
        self.status_var = tk.StringVar(value="Ready.")
        tk.Label(bar, textvariable=self.status_var, bg=BORDER, fg=MUTED,
                 font=("Courier New", 9), anchor="w").pack(side="left", padx=12)

    # ── Table helpers ─────────────────────────────────────────────────────────
    def _refresh_table(self):
        query = self.search_var.get().upper()
        self.tree.delete(*self.tree.get_children())
        for a in self.airports:
            if query and query not in a.ICAO.upper():
                continue
            tag   = "schengen" if a.schengen else "no_schengen"
            badge = "✔  Yes"   if a.schengen else "✘  No"
            self.tree.insert("", "end", iid=str(id(a)),
                             values=(a.ICAO, f"{a.latitude:.5f}",
                                     f"{a.longitude:.5f}", badge),
                             tags=(tag,))
        self._update_count()

    def _update_count(self):
        n_s, n = CountSchengen(self.airports)   # logic lives in airport.py
        self.count_lbl.config(
            text=f"{n} airport{'s' if n != 1 else ''} loaded  •  {n_s} Schengen"
        )

    def _on_select(self, _event):
        sel = self.tree.selection()
        if not sel:
            return
        v = self.tree.item(sel[0], "values")
        self.detail_lbl.config(
            text=f"  ICAO: {v[0]}   │   Lat: {v[1]}   │   Lon: {v[2]}   │   Schengen: {v[3]}",
            fg=TEXT
        )

    def _sort_by(self, col):
        data = [(self.tree.set(k, col), k) for k in self.tree.get_children("")]
        data.sort()
        for idx, (_, k) in enumerate(data):
            self.tree.move(k, "", idx)

    def _status(self, msg):
        self.status_var.set(msg)

    # ══════════════════════════════════════════════════════════════════════════
    # EVENT HANDLERS — UI only; all logic delegated to airport.py
    # ══════════════════════════════════════════════════════════════════════════

    def _on_load(self):
        path = filedialog.askopenfilename(
            title="Select airports file",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not path:
            return
        # airport.py does all the work
        loaded = LoadAirports(path)
        if not loaded:
            messagebox.showerror("Error", f"Could not load airports from:\n{path}")
            return
        for a in loaded:
            AddAirport(self.airports, a)
        self._refresh_table()
        self._status(f"Loaded {len(loaded)} airports from {path}")

    def _on_save_schengen(self):
        if not self.airports:
            messagebox.showwarning("Empty list", "No airports in memory to save.")
            return
        path = filedialog.asksaveasfilename(
            title="Save Schengen airports",
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        if not path:
            return
        # airport.py does the saving
        result = SaveSchengenAirports(self.airports, path)
        if result == -1:
            messagebox.showerror("Error", "No airports in the list.")
        else:
            n_s, _ = CountSchengen(self.airports)
            self._status(f"Saved {n_s} Schengen airports to {path}")
            messagebox.showinfo("Saved", f"{n_s} Schengen airports saved to:\n{path}")

    def _on_add(self):
        """Two-step dialog: ask ICAO + optional coords. Logic in airport.py."""
        dlg = tk.Toplevel(self.root)
        dlg.title("Add Airport")
        dlg.configure(bg=PANEL)
        dlg.resizable(False, False)
        dlg.grab_set()

        icao_var   = tk.StringVar()
        has_coords = tk.BooleanVar(value=True)

        # Step 1
        step1 = tk.Frame(dlg, bg=PANEL)
        step1.pack(padx=24, pady=(16, 8), fill="x")

        make_label(step1, "ADD NEW AIRPORT", fg=ACCENT, font_size=12).grid(
            row=0, column=0, columnspan=2, pady=(0, 12))

        make_label(step1, "ICAO code:").grid(row=1, column=0, sticky="e", padx=(0, 8), pady=4)
        icao_entry = styled_entry(step1, textvariable=icao_var, width=12)
        icao_entry.grid(row=1, column=1, sticky="w", pady=4)
        icao_entry.focus_set()

        tk.Checkbutton(
            step1, text="I have the coordinates (lat / lon)",
            variable=has_coords,
            bg=PANEL, fg=TEXT, selectcolor=ENTRY_BG,
            activebackground=PANEL, activeforeground=ACCENT,
            font=("Courier New", 9), cursor="hand2"
        ).grid(row=2, column=0, columnspan=2, sticky="w", pady=(8, 4))

        # Step 2 (hidden initially)
        step2  = tk.Frame(dlg, bg=PANEL)
        lat_var = tk.StringVar()
        lon_var = tk.StringVar()

        make_label(step2, "Latitude (°):").grid( row=0, column=0, sticky="e", padx=(0, 8), pady=4)
        lat_entry = styled_entry(step2, textvariable=lat_var, width=16)
        lat_entry.grid(row=0, column=1, sticky="w", pady=4)

        make_label(step2, "Longitude (°):").grid(row=1, column=0, sticky="e", padx=(0, 8), pady=4)
        styled_entry(step2, textvariable=lon_var, width=16).grid(row=1, column=1, sticky="w", pady=4)

        make_label(step2, "Tip: positive = North/East  •  negative = South/West",
                   font_size=8).grid(row=2, column=0, columnspan=2, pady=(4, 0))

        btn_row = tk.Frame(dlg, bg=PANEL)
        btn_row.pack(pady=(4, 16))

        def _commit():
            """Hand raw inputs to airport.py for validation and creation."""
            lat = lat_var.get() if has_coords.get() else "0.0"
            lon = lon_var.get() if has_coords.get() else "0.0"

            # CreateAirport() in airport.py validates and builds the object
            airport, err = CreateAirport(icao_var.get(), lat, lon)
            if err:
                messagebox.showerror("Invalid input", err, parent=dlg)
                return

            # AddAirport() in airport.py checks for duplicates
            added = AddAirport(self.airports, airport)
            if not added:
                messagebox.showwarning("Duplicate",
                                       f"Airport '{airport.ICAO}' already exists.",
                                       parent=dlg)
                return

            self._refresh_table()
            coord_str = f"{airport.latitude:.4f}, {airport.longitude:.4f}" \
                        if has_coords.get() else "no coordinates"
            self._status(f"Added {airport.ICAO}  ({coord_str})  Schengen: {airport.schengen}")
            dlg.destroy()

        def _next():
            if has_coords.get():
                step2.pack(padx=24, pady=(0, 8), fill="x")
                lat_entry.focus_set()
                next_btn.config(text="✔  Add", command=_commit)
            else:
                _commit()

        next_btn = styled_btn(btn_row, "Next  ›", _next,       ACCENT2, 10)
        next_btn.pack(side="left", padx=6)
        styled_btn(btn_row, "✘  Cancel", dlg.destroy, WARN, 10).pack(side="left", padx=6)
        dlg.bind("<Return>", lambda e: next_btn.invoke())

    def _on_remove(self):
        sel = self.tree.selection()
        if sel:
            code = self.tree.item(sel[0], "values")[0]
            if messagebox.askyesno("Confirm", f"Remove airport {code}?"):
                RemoveAirport(self.airports, code)   # airport.py does the work
                self._refresh_table()
                self._status(f"Removed airport {code}")
        else:
            # No row selected — ask for ICAO code
            dlg = tk.Toplevel(self.root)
            dlg.title("Remove Airport")
            dlg.configure(bg=PANEL)
            dlg.resizable(False, False)
            dlg.grab_set()

            make_label(dlg, "ICAO code to remove:", fg=TEXT, font_size=10).grid(
                row=0, column=0, padx=16, pady=12)
            var = tk.StringVar()
            styled_entry(dlg, textvariable=var, width=10).grid(row=0, column=1, padx=(0, 16))

            def _do():
                code = var.get().strip().upper()
                result = RemoveAirport(self.airports, code)  # airport.py
                if result == -1:
                    messagebox.showerror("Not found", f"Airport '{code}' not found.", parent=dlg)
                else:
                    self._refresh_table()
                    self._status(f"Removed airport {code}")
                    dlg.destroy()

            br = tk.Frame(dlg, bg=PANEL)
            br.grid(row=1, column=0, columnspan=2, pady=(0, 12))
            styled_btn(br, "Remove", _do,        WARN,   10).pack(side="left", padx=6)
            styled_btn(br, "Cancel", dlg.destroy, ACCENT, 10).pack(side="left", padx=6)

    def _on_set_schengen(self):
        if not self.airports:
            messagebox.showwarning("Empty list", "No airports loaded.")
            return
        count = SetAllSchengen(self.airports)   # airport.py does the work
        self._refresh_table()
        self._status(f"Schengen updated: {count} of {len(self.airports)} airports are Schengen")

    def _on_plot(self):
        err = PlotAirports(self.airports)       # airport.py does the work
        if err:
            messagebox.showwarning("No data", err)

    def _on_export_kml(self):
        path = filedialog.asksaveasfilename(
            title="Export KML",
            defaultextension=".kml",
            filetypes=[("KML files", "*.kml"), ("All files", "*.*")]
        )
        if not path:
            return
        err = MapAirports(self.airports, path)  # airport.py does the work
        if err:
            messagebox.showerror("Error", err)
        else:
            self._status(f"KML exported to {path}")
            messagebox.showinfo("Exported",
                                f"KML file saved to:\n{path}\n\nOpen it with Google Earth.")

    def _on_clear(self):
        if not self.airports:
            return
        if messagebox.askyesno("Confirm", "Clear ALL airports from memory?"):
            self.airports.clear()
            self._refresh_table()
            self._status("All airports cleared.")


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    root = tk.Tk()
    AirportApp(root)
    root.mainloop()
